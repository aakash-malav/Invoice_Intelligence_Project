import joblib
import pandas as pd

MODEL_PATH = "models/predict_flag_invoice.pkl"


def load_model(model_path: str = MODEL_PATH):
    """
    Load trained invoice flagging classifier.
    """

    with open(model_path, "rb") as f:
        model = joblib.load(f)

    return model


def predict_invoice_flag(input_data):
    """
    Predict whether new vendor invoices should be flagged.

    Parameters
    ----------
    input_data : dict

    Returns
    -------
    pd.DataFrame with predicted invoice flag
    """

    model = load_model()

    input_df = pd.DataFrame(input_data)

    input_df["Predicted_Flag"] = model.predict(input_df)

    return input_df


if __name__ == "__main__":

    # Example inference run (local testing)

    sample_data = {

        "invoice_quantity": [250, 400],

        "invoice_dollars": [12000, 18000],

        "Freight": [850, 1300],

        "total_item_quantity": [255, 405],

        "total_item_dollars": [11950, 17920]

    }

    prediction = predict_invoice_flag(sample_data)

    print(prediction)