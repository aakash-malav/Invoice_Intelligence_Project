import joblib

from pathlib import Path

from data_preprocessing import (
    load_vendor_invoice_data,
    prepare_features,
    split_data
)

from model_evaluation import (
    train_linear_regression,
    train_decision_tree,
    train_random_forest,
    evaluate_model
)



def main():

    # Create models directory

    model_dir = Path("models")

    model_dir.mkdir(exist_ok=True)

    # -------------------------
    # Load Data
    # -------------------------

    vendor_df = load_vendor_invoice_data()

    print("Data Loaded Successfully")
    print(f"Rows: {vendor_df.shape[0]}")
    print(f"Columns: {vendor_df.shape[1]}")

    # -------------------------
    # Prepare Features
    # -------------------------

    X, Y = prepare_features(vendor_df)

    # -------------------------
    # Split Data
    # -------------------------

    X_train, X_test, Y_train, Y_test = split_data(
        X,
        Y
    )

    # -------------------------
    # Train Models
    # -------------------------

    lr_model = train_linear_regression(
        X_train,
        Y_train
    )

    dt_model = train_decision_tree(
        X_train,
        Y_train
    )

    rf_model = train_random_forest(
        X_train,
        Y_train
    )

    # -------------------------
    # Evaluate Models
    # -------------------------

    results = []

    results.append(
        evaluate_model(
            lr_model,
            X_test,
            Y_test,
            "Linear Regression"
        )
    )

    results.append(
        evaluate_model(
            dt_model,
            X_test,
            Y_test,
            "Decision Tree Regression"
        )
    )

    results.append(
        evaluate_model(
            rf_model,
            X_test,
            Y_test,
            "Random Forest Regression"
        )
    )

    # -------------------------
    # Select Best Model
    # -------------------------

    best_model_info = min(
        results,
        key=lambda x: x["mae"]
    )

    best_model_name = best_model_info["model_name"]

    best_model = {
        "Linear Regression": lr_model,
        "Decision Tree Regression": dt_model,
        "Random Forest Regression": rf_model
    }[best_model_name]

    # -------------------------
    # Save Model
    # -------------------------

    model_path = (
        model_dir /
        "predict_freight_model.pkl"
    )

    joblib.dump(
        best_model,
        model_path
    )

    print("\nBest Model Saved")

    print(
        f"Best Model : {best_model_name}"
    )

    print(
        f"Location : {model_path}"
    )


if __name__ == "__main__":
    main()