import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
from sklearn.model_selection import train_test_split
from db_connection import engine


def load_vendor_invoice_data():
    """
    Load vendor invoice data from PostgreSQL.
    """

    query = """
    SELECT *
    FROM vendor_invoice
    """
    df = pd.read_sql(query, engine)
    return df


def prepare_features(df: pd.DataFrame):
    """
    Select features and target variable.
    """

    X = df[["Dollars"]]
    Y = df["Freight"]

    return X, Y


def split_data(X, Y, test_size=0.2, random_state=42):
    """
    Split dataset into train and test sets.
    """
    return train_test_split(
        X, Y, test_size=test_size, random_state=random_state
    )