from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score
)


def train_linear_regression(X_train, Y_train):
    """
    Train a Linear Regression model.
    """

    model = LinearRegression()

    model.fit(X_train, Y_train)

    return model


def train_decision_tree(
    X_train,
    Y_train,
    max_depth=5
):
    """
    Train a Decision Tree Regressor.
    """

    model = DecisionTreeRegressor(
        max_depth=max_depth,
        random_state=42
    )

    model.fit(X_train, Y_train)

    return model


def train_random_forest(
    X_train,
    Y_train,
    n_estimators=100,
    max_depth=6
):
    """
    Train a Random Forest Regressor.
    """

    model = RandomForestRegressor(
        n_estimators=n_estimators,
        max_depth=max_depth,
        random_state=42
    )

    model.fit(X_train, Y_train)

    return model


def evaluate_model(
    model,
    X_test,
    Y_test,
    model_name
):
    """
    Evaluate regression model and return metrics.
    """

    preds = model.predict(X_test)

    mae = mean_absolute_error(Y_test, preds)

    rmse = mean_squared_error(Y_test, preds) ** 0.5

    r2 = r2_score(Y_test, preds)

    print(f"\n{model_name} Performance")
    print("-" * 40)
    print(f"MAE  : {mae:.2f}")
    print(f"RMSE : {rmse:.2f}")
    print(f"R²   : {r2:.4f}")

    return {
        "model_name": model_name,
        "mae": mae,
        "rmse": rmse,
        "r2": r2
    }