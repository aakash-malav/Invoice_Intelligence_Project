import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from db_connection import engine

def load_invoice_data():
    """
    Load invoice data from PostgreSQL.
    """

    query = """
    WITH purchase_agg AS (

        SELECT

            p."PONumber",

            COUNT(DISTINCT p."Brand") AS total_brands,

            SUM(p."Quantity") AS total_item_quantity,

            SUM(p."Dollars") AS total_item_dollars,

            AVG(
                TO_DATE(p."ReceivingDate",'YYYY/MM/DD')
                -
                TO_DATE(p."PODate",'YYYY/MM/DD')
            ) AS avg_receiving_delay

        FROM purchases p

        GROUP BY p."PONumber"

    )

    SELECT

        vi."PONumber",

        vi."Quantity" AS invoice_quantity,

        vi."Dollars" AS invoice_dollars,

        vi."Freight",

        (
            TO_DATE(vi."InvoiceDate",'YYYY/MM/DD')
            -
            TO_DATE(vi."PODate",'YYYY/MM/DD')
        ) AS days_po_to_invoice,

        (
            TO_DATE(vi."PayDate",'YYYY/MM/DD')
            -
            TO_DATE(vi."InvoiceDate",'YYYY/MM/DD')
        ) AS days_to_pay,

        pa.total_brands,

        pa.total_item_quantity,

        pa.total_item_dollars,

        pa.avg_receiving_delay

    FROM vendor_invoice vi

    LEFT JOIN purchase_agg pa

        ON vi."PONumber" = pa."PONumber"
    """

    df = pd.read_sql_query(query, engine)

    return df


def create_invoice_risk_label(row):

    if abs(row["invoice_dollars"] - row["total_item_dollars"]) > 5:
        return 1

    if row["avg_receiving_delay"] > 10:
        return 1

    return 0


def apply_labels(df):

    df["flag_invoice"] = df.apply(
        create_invoice_risk_label,
        axis=1
    )

    return df



def split_data(df, features, target):

    X = df[features]

    y = df[target]

    return train_test_split(
        X,
        y,
        test_size=0.20,
        random_state=42,
        stratify=y
    )


def scale_features(X_train, X_test, scaler_path):

    scaler = StandardScaler()

    X_train_scaled = scaler.fit_transform(X_train)

    X_test_scaled = scaler.transform(X_test)

    joblib.dump(scaler, scaler_path)

    return X_train_scaled, X_test_scaled


